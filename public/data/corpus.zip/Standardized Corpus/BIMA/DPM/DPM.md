# DPM Fakultas Ilmu Komputer 

## Ketua
FIJA RAMADHAN

## Sekretaris 
BELLA SIFA LAREKU

## Visi
Terwujudnya DPM FIK sebagai lembaga yang ter-ARAH (Akuntabilitas, Representatif, Aspiratif, dan Harmonis) dalam menjalankan fungsinya sebagai lembaga legislatif di lingkup Fakulats Ilmu Komputer.

## Misi
1. Meningkatkan kapasitas dan solidaritas internal DPM FIK Udinus dengan asas kekeluargan.
2. Optimalisasi peran dan fungsi advokasi yang akuntabel dan transparan.
3. Menetapkan produk hukum dan penyerapan aspirasi yang bersifat representatif bagi kepentingan Fakultas Ilmu Komputer Universitas Dian Nuswantoro.

## Definisi
DPM-FIK (Dewan Perwakilan Mahasiswa - Fakultas Ilmu Komputer) merupakan lembaga di lingkup Fakultas Ilmu Komputer yang menjalankan fungsi legislasi, pengawasan, dan advokasi. DPM-FIK mempunyai jargon “SUYA”, “SUYA” sendiri merupakan singkatan dari Speak Up Your Aspiration. Jargon tersebut memiliki arti untuk mengajak seluruh mahasiswa UDINUS di lingkup Fakultas Ilmu Komputer untuk menyampaikan aspirasinya. Kami bertugas mengawasi sekaligus mengevaluasi kinerja BEM Fasilkom dan juga HM dan Biro di FIK, menyusun dan menetapkan undang-undang, menyaring aspirasi mahasiswa kemudian menyampaikannya ke pihak akademik.

## Bidang Komisi
1. Komisi Legislasi 
2. Komisi Advokasi 
3. Komisi Budgeting 
4. Komisi Infokom 
5. Komisi KPSDM

## Sejarah Organisasi