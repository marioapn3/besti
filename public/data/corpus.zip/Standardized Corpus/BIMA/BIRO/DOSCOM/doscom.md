# Dinus Open Source Community (DOSCOM)

## Ketua Umum

RIFQIS SAKHA HILMI AZIZ

## Sekretaris

DHEA MAHARANI

## Visi

Mewujudkan komunitas yang inovatif, kolaboratif, dan berdaya saing lewat tagline "Memasyarakatkan Open Source dan Meng-Open Source-kan masyarakat."

## Misi

1. Menyediakan pelatihan intensif tentang pengembangan keterampilan dalam ranah Open Source.
2. Membangun kerjasama dengan organisasi/komunitas baik di dalam maupun di luar Universitas.
3. Menciptakan suasana keanggotaan DOSCOM yang harmonis dan berlandaskan kekeluargaan.

## Definisi

Dinus Open Source Community (DOSCOM) adalah sebuah komunitas Open Source yang bergerak di bidang software/perangkat lunak yang mengusung visi "Memasyarakatkan Open Source dan Meng-open source-kan Masyarakat" dibawah naungan Fakultas Ilmu Komputer - Universitas Dian Nuswantoro.

## Sejarah Organisasi

Dinus Open Source Community (DOSCOM) merupakan sebuah komunitas yang terdiri dari mahasiswa, pelajar, dan masyarakat yang aktif dalam penggunaan Open Source Software (OSS). Komunitas ini dulunya bernama Gabungan Linuxer Mahasiswa Dian Nuswantoro (GLADIATOR) yang dibentuk pada tanggal 27 November 2003 oleh Universitas Dian Nuswantoro. Setelah vakum selama 2 tahun, pada tanggal 16 Oktober 2007, DOSCOM aktif kembali dan menjadi salah satu provokator dalam memasyarakatkan dunia Teknologi Informasi dengan Open Source Software (OSS) di Indonesia. Dengan dukungan penuh dari Kementrian Riset dan Teknologi Republik Indonesia dan Jawa Tengah Open Source Center, DOSCOM dengan misinya memasnyarakatkan open source dan mengopen-sourcekan masyarakat bertekad kuat untuk berbagi, dan menyebarkan ilmu open source kepada masyarakat.
