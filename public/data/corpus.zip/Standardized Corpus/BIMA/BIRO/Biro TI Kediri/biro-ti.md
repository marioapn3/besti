# Biro Teknik Informatika Universitas Dian Nuswantoro (UDINUS)

## Ketua

ANS' AKMAL SURYA MYRIANO

## Sekretaris

SHINTA RACHMA YULIANTI

## Visi

Menjadikan Biro Teknik Informatika yang bersatu dan berkualitas demi tercapainya visi misi program studi Informatika Udinus Kediri dengan semangat juang Biro Teknik Informatika yang progresif, responsif, inovatif, dan pastinya peduli rakyat.

## Misi

1. Bertakwa pada Tuhan YME.
2. Meningkatkan sumber daya mahasiswa yang aktif, kreatif, dan inovatif di bidang akademik maupun non-akademik.
3. Melaksanakan program-program yang tersusun sesuai rencana (proker).
4. Menjalin hubungan baik dan kerja sama dengan organisasi mahasiswa lainnya serta menjaga nama baik biro dan almamater.

## Sejarah Organisasi

Biro Teknik Informatika (Biro TI) merupakan sebuah organisasi kampus di tingkat Program Studi Teknik Informatika. Biro Teknik Informatika didirikan pada hari Senin, tanggal 12 Juli 2021, dan berkedudukan di Jurusan Teknik Informatika Universitas Dian Nuswantoro.

Biro Teknik Informatika didirikan dengan prinsip Disiplin, Kejujuran, Kreativitas, Keadilan, Kebersamaan, Kekeluargaan, Kerakyatan, Keilmuan, dan Toleransi. Tujuan dari Biro Teknik Informatika adalah menampung seluruh elemen mahasiswa Jurusan Teknik Informatika Fakultas Teknik Universitas Dian Nuswantoro menuju kehidupan kampus yang kritis, bertanggung jawab, dinamis, demokratis, dan harmonis.

Untuk informasi lebih lanjut, kunjungi website Biro TI: [Biro TI Udinus Kediri](https://hmti.kediri.dinus.ac.id/)
