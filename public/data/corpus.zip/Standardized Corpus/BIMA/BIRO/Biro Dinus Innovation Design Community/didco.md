# Biro Dinus Innovation Design Community (DID.Co) Universitas Dian Nuswantoro (UDINUS)

## Ketua

GERBY PUTRI OKTAFIA

## Sekretaris

LAILA SYARIFAH WAHDANI

## Visi

DID.Co menjadi organisasi desain terdepan yang mempromosikan inovasi dan kreativitas di bidang desain.

## Misi:

Menyediakan platform bagi para mahasiswa terkait desainer untuk berkembang, berkolaborasi, dan menciptakan karya yang berdampak positif di komunitas.

## Sejarah Organisasi

DID.Co adalah biro yang dibawah naungan Fakultas Teknik yang bertujuan untuk mewadahi mahasiswa dengan minat di bidang 3D design, khususnya 3D design engineering. Biro ini berfokus pada berbagi program kerja dan ilmu pengetahuan, khususnya yang terkait dengan bidang teknik di Fakultas Teknik.
