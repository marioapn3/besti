# Biro Animasi Universitas Dian Nuswantoro (UDINUS)

## Ketua

ANTONIUS ALANA SETIA PUTRA

## Sekretaris

SEKAR AYU HAPSZARY

## Visi:

Mewujudkan himpunan mahasiswa animasi yang aktif sebagai pendorong dalam menciptakan sinergi keluarga besar mahasiswa animasi, demi terwujudnya mahasiswa yang solid, peduli, humanis, dan mampu menghasilkan mahasiswa berprestasi kelas dunia.

## Misi:

1. Menyalurkan bakat minat mahasiswa untuk meningkatkan sumber daya manusia yang berkualitas.
2. Menyelenggarakan kegiatan yang berkualitas, sehingga mampu meningkatkan apresiasi masyarakat terhadap animasi Indonesia.
3. Menumbuhkan rasa kepedulian serta tanggung jawab terhadap kondisi lingkungan jurusan, fakultas, universitas, dan sosial masyarakat.
4. Menjadi wadah dalam menyampaikan aspirasi mahasiswa animasi.

## Sejarah Organisasi

Biro Animasi adalah organisasi yang menaungi mahasiswa animasi di bawah Fakultas Ilmu Komputer. Organisasi ini dimulai dari keinginan mahasiswa animasi untuk membuat acara-acara tahunan, maka dibentuklah Biro Animasi pada tahun 2017. Beranggotakan 20 mahasiswa animasi yang diketuai oleh Moh.Rudi Gunawan. Di masa sekarang, Biro Animasi tidak hanya menyelenggarakan acara-acara yang menarik, tetapi banyak dari anggotanya mengembangkan bakat dalam animasi, menghasilkan karya-karya yang menarik serta kreatif, serta merangkul seluruh mahasiswa animasi untuk bersosialisasi bersama, berkolaborasi dalam karya, dan menjadi jembatan antara mahasiswa dengan program studi animasi.
