# Biro Manajemen Kediri Universitas Dian Nuswantoro (UDINUS)

## Ketua

ALEK ZAIN MADANY

## Sekretaris

USWATUN KASANAH

## Visi

Menjadi organisasi mahasiswa yang unggul dalam perkembangan sivitas akademika yang prima dengan tata kelola yang kuat dan efisien, berkomitmen untuk mewujudkan organisasi yang transparan, responsif, dan akuntabel.

## Misi

1. Memperkuat tata kelola yang baik dan akuntabel dalam pengelolaan aset organisasi.
2. Meningkatkan efisiensi dan efektivitas proses kerja melalui penerapan sistem manajemen yang terintegrasi.
3. Membentuk karakter mahasiswa yang berintegritas, etis, dan memiliki jiwa kepemimpinan.

## Sejarah Organisasi

Biro Prodi Manajemen merupakan salah satu organisasi biro program studi yang ada di PSDKU Universitas Dian Nuswantoro Kediri yang memiliki tujuan untuk maju dan berkembang bersama.  
Biro Prodi Manajemen dibentuk untuk menjadi wadah dalam mendukung setiap pelaksanaan kegiatan mahasiswa, khususnya mahasiswa jurusan manajemen yang ada di PSDKU Universitas Dian Nuswantoro Kediri.
