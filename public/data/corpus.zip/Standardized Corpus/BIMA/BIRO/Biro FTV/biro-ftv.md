# Biro Film dan Televisi Universitas Dian Nuswantoro (UDINUS)

## Ketua

SAMUEL ALVIN HARYANTO

## Sekretaris

I DEWA GEDE TRISNA RIANDIKA

## Visi

Menjadikan wadah untuk mahasiswa Film dan Televisi guna menerapkan ilmu yang didapat dari perkuliahan sehingga dapat terjun langsung di bidang industri perfilman melalui kegiatan prodi.

## Misi:

1. Mahasiswa mampu melatih dirinya mengelola sebuah kelompok atau organisasi dalam kegiatan produksi film, pemutaran film, atau penulisan kritik film.
2. Mahasiswa mendapat ruang untuk membangun relasi dengan pelaku/kelompok industri film di luar lingkungan prodi dengan harapan dapat menjalin kerja sama.
3. Mengarahkan minat & bakat mahasiswa melalui kegiatan terencana dan mendukung penuh potensi mahasiswa di bidang perfilman.

## Sejarah Organisasi

Sehubungan dengan kebutuhan mahasiswa untuk mengimplementasikan referensi yang diperoleh dari perkuliahan, dibentuklah sebuah wadah yang menjadi ruang bagi mahasiswa. Ruang tersebut digunakan untuk berkegiatan dalam bidang film di luar aktivitas perkuliahan. Ruang dan kegiatan ini juga menjadi kebutuhan utama bagi mahasiswa untuk membangun jaringan komunitas film di luar kampus (baik lokal di wilayah Semarang, nasional, maupun internasional).

Hal ini menjadi kegiatan yang penting, mengingat mempersiapkan mahasiswa untuk terbiasa berada dalam sistem berjejaring dengan lingkaran jaringan yang luas, karena hal ini merupakan kebutuhan utama untuk menjajaki tahap ke-profesian dalam film setelah purna menjadi mahasiswa. Ruang dan kegiatan ini dikelola oleh mahasiswa dalam wadah bernama Biro Film dan Televisi Universitas Dian Nuswantoro. Dalam pelaksanaan kegiatannya, Biro FTV melakukan kerja-kerja pemutaran film, pengelolaan arsip film, dan visitasi ke festival film atau eksibisi film di Indonesia sebagai pembelajaran untuk mengelola sistem internal Biro FTV.
