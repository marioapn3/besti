# Tax Center Universitas Dian Nuswantoro (UDINUS)

## Ketua Umum

NADHIFA KHAIRUNNISA QATRUNNADA

## Sekretaris

ADELLIA DINDA PRAMUDITHA

## Visi

Menjadikan Tax Center Universitas Dian Nuswantoro sebagai organisasi yang progresif, adaptif, inovatif serta sebagai wadah pengembangan mahasiswa dalam bidang perpajakan.

## Misi

1. Memberikan pengetahuan pajak bagi internal dan eksternal organisasi.
2. Menciptakan kaderisasi yang baik sesuai dengan visi Tax Center Universitas Dian Nuswantoro.
3. Menjalin kerjasama dengan mitra organisasi eksternal.

## Sejarah Organisasi

Nama Organisasi adalah Tax Center yang diresmikan pada 21 Januari 2014 yang bertempat Gedung C Lantai 1. Tax Center adalah biro kerja sama antara Universitas Dian Nuswantoro dengan Kanwil Direktorat Jenderal Pajak Jawa Tengah I. Tax Center bergerak di bidang perpajakan yang menyediakan fasilitas informasi untuk layanan perpajakan dan juga dapat menjadi pusat informasi mengenai pajak kepada civitas akademik Universitas Dian Nuswantoro. Tax Center didirikan guna mewujudkan kesadaran dan kepedulian masyarakat dalam memahami perpajakan dan wajib pajak. Selain itu, Tax Center juga dijadikan sebagai laboratorium pajak di Universitas Dian Nuswantoro.

Tax Center Universitas Dian Nuswantoro diresmikan pada selasa, 21 Januari 2014 oleh Kepala Kanwil Direktorat Jenderal Pajak Jawa Tengah I, Edi Slamet Iriyanto. Pendirian Tax Center ini sebagai bentuk kerja sama antara Universitas Dian Nuswantoro dengan Kanwil Ditjen Pajak Jateng I. Tax Center didirikan sebagai bentuk upaya meningkatkan kesadaran pajak di kalangan civitas akademik Universitas Dian Nuswantoro dan masyarakat umum. Tax Center terletak di gedung C lantai 1.
