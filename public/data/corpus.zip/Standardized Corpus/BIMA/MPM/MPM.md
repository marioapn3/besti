# MPM Keluarga Mahasiswa 

## Ketua 
BERNANDIKO PRIYAMBODO

## Sekretaris
BERNANDIKO PRIYAMBODO

## Visi 
Mewujudkan MPM-KM UDINUS yang proaktif, inovatif, dan responsif dalam menjalankan kedaulatan mahasiswa serta berperan sebagai penggerak utama dalam pembangunan karakter dan kualitas mahasiswa Universitas Dian Nuswantoro.

## Misi
1. Meningkatkan koordinasi dan sinergi antara ormawa universitas.
2. Mengimplementasikan sistem audit yang transparan dan akuntabel terhadap kinerja ormawa universitas.
3. Mewujudkan sinergitas dengan civitas akademika.

## Definisi
Majelis Permusyawaratan Mahasiswa Keluarga Mahasiswa Universitas Dian Nuswantoro selanjutnya disebut MPM-KM UDINUS merupakan Lembaga Kemahasiswaan Tertinggi, pemegang dan pelaksana kedaulatan Mahasiswa Universitas Dian Nuswantoro.

## Sejarah Organisasi