# Pimpinan Kampus

## Pimpinan UDINUS
### Rektor dan Pendiri
Prof. Dr. Ir EDI NOERSASONGKO, M.Kom

### Wakil Rektor 
#### Wakil Rektor 1 
Prof. Dr. Supriadi Rustad, M.Si
Bidang Akademik
#### Wakil Rektor 2
Dr. Guruh Fajar Shidik, S.Kom. , M.Cs
Bidang Umum dan Keuangan
#### Wakil Rektor 3 
Dr. Kusni Ingsih, MM
Bidang Kemahasiswaan
#### Wakil Rektor 4 
Prof. Dr. Pulung Nurtantio Andono, S.T, M.Kom.
Bidang Penelitian dan Kerjasama

## Pimpinan Biro 
### Biro Administrasi Akademik
Achmad Wahid Kurniawan S.Si, M.Kom
### Biro Keuangan 
Yunita, S.E, M.Si
### Biro Kemahasiswaan
Dr. Rindra Yusianto, S.Kom, M.T
### Biro Admisi dan Promosi
Andi Hallang Lewa, S.S, M.M
### Biro Umum
Sarju, S.Kom., M.M

## Pimpinan Lembaga
### Lembaga Penelitian dan Pengabdian Masyarakat
Dr. Eng. Yuliman Purwanto, M.Eng
### Lembaga Center Of Excellence
Prof. Dr. Drs. Jumanto, M.Pd.
### Lembaga Pengembangan dan Pembelajaran Kurikulum
Dr. Pujiono S.Si., M.Kom
### Lembaga Kerjasama
Dr. Ir. Dwi Eko Waluyo, M.M
### Lembaga Penjamin Mutu
Dr. Nova Rijati, S.Si., M.Kom

## Pimpinan Unit Pelaksanaan Teknis 
### UPT Data dan Informasi
Dr. Heribertus Himawan M.Kom
### UPT Poliklinik
Dr. Anggoro Dhana Octavian
### UPT Layanan Alumni dan Karir
Dr. Sendi Novianto S.Kom, M.T
### UPT Kewirausahaan
Dr. Nila Tristiarini SE, MSi, CSRA
### UPT Dinustek
Moch. Siddiq, S.Si, M.Kom
### UPT Perpustakaan
Aan Prabowo, S.Hum., MA
### UPT Lembaga Sertifikasi dan Profesi
Dr. Supriyono Asfawi, SE., M.Kes
### UPT Humas dan Protokoler
Dwi Utaminingsih, S.Kom, M.M
### UPT Penerbitan
Achmintarto, S.Kom., MM