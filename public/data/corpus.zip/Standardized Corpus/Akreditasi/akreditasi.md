# Akreditasi Setiap Program Studi di UDINUS

## Akreditasi Program Studi Ilmu Komputer (S3)
Kode Prodi: P41
Program Studi: Ilmu Komputer
Jenjang: Doktor
No SK Akreditasi: 11405/SK/BAN-PT/Akred/D/X/2021
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 05 Oktober 2026
Link Sertifikat: https://drive.google.com/drive/folders/16M742dqay2nnFm1TzFYf0I_7Sdc8Se0C?usp=drive_link
  
## Akreditasi Program Studi Teknik Informatika (S2)
Kode Prodi: P31
Program Studi: Teknik Informatika
Jenjang: Magister
No SK Akreditasi: 6800/SK/BAN-PT/Akred/M/X/2020
Peringkat Terbaru: B
Masa Berlaku: 17 Juli 2025
Link Sertifikat: https://drive.google.com/drive/folders/16Mp6R5PtGS9bthiB2vt7UwpkQB3qYhJ5?usp=drive_link
  
## Akreditasi Program Studi Teknik Informatika (S1)
Kode Prodi: A11
Program Studi: Teknik Informatika
Jenjang: Sarjana
No SK Akreditasi: 5507/SK/BAN-PT/Ak.KP/S/VIII/2022
Peringkat Terbaru: Unggul
Masa Berlaku: 4-Sep-25
Link Sertifikat: https://drive.google.com/drive/folders/15zJkBGI7VkmQeDc9ri4bSr2PpI4U4iwD?usp=drive_link
  
## Akreditasi Program Studi Sistem Informasi (S1)
Kode Prodi: A12
Program Studi: Sistem Informasi
Jenjang: Sarjana
No SK Akreditasi: 2440/SK/BAN-PT/AK-ISK/S/IV/2022
Peringkat Terbaru: Unggul
Masa Berlaku: 15 Desember 2025
Link Sertifikat: https://drive.google.com/drive/folders/15l-btCPigea-IfywB26cfHZFznfGbkWu?usp=drive_link
  
## Akreditasi Program Studi Desain Komunikasi Visual (S1)
Kode Prodi: A14
Program Studi: Desain Komunikasi Visual
Jenjang: Sarjana
No SK Akreditasi: 3769/SK/BAN-PT/Ak.KP/S/IX/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 15-Nov-25
Link Sertifikat: https://drive.google.com/drive/folders/16HePu2VLdPX0y4TWorWt_OCzRAys1mdq?usp=drive_link
  
## Akreditasi Program Studi Ilmu Komunikasi (S1)
Kode Prodi: A15
Program Studi: Ilmu Komunikasi
Jenjang: Sarjana
No SK Akreditasi: 1017/SK/BAN-PT/Ak/S/III/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 21 Maret 2028
Link Sertifikat: https://drive.google.com/drive/folders/16GoS2o-W1RBLwATJTvSSkjalMhTclGRW?usp=drive_link
  
## Akreditasi Program Studi Film dan Televisi (D4)
Kode Prodi: A16
Program Studi: Film Dan Televisi
Jenjang: Sarjana Terapan
No SK Akreditasi: 4577/SK/BAN-PT/Ak.Ppj/STr/VI/2024
Peringkat Terbaru: B
Masa Berlaku: 19 Juni 2029
Link Sertifikat: https://drive.google.com/drive/folders/16D3rSRQeiYLn5cQPJEsigW28PO2_lnF5?usp=drive_link
  
## Akreditasi Program Studi Animasi (D4)
Kode Prodi: A17
Program Studi: Animasi
Jenjang: Sarjana Terapan
No SK Akreditasi: 4555/SK/BAN-PT/Ak/STr/VI/2024
Peringkat Terbaru: Unggul
Masa Berlaku: 04 Juni 2029
Link Sertifikat: https://drive.google.com/drive/folders/16ASkTp1MvaSFf_hxtGuiWi80VVXaINtv?usp=drive_link
  
## Akreditasi Program Studi PJJ Informatika (S1)
Kode Prodi: A18
Program Studi: PJJ Informatika
Jenjang: Sarjana
No SK Akreditasi: 10502/SK/BAN-PT/Ak.P/S/XII/2022
Peringkat Terbaru: Baik
Masa Berlaku: 26 Desember 2024
Link Sertifikat: https://drive.google.com/drive/folders/1DZCAnh3J8QGjVHQjAdDGF0DIivN6xazh?usp=drive_link
  
## Akreditasi Program Studi Teknik Informatika (D3)
Kode Prodi: A22
Program Studi: Teknik Informatika
Jenjang: Diploma
No SK Akreditasi: 1922/SK/BAN-PT/Ak.KP/D3/V/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 23-Sep-25
Link Sertifikat: https://drive.google.com/drive/folders/1681ltRWAFaSORE8J8GFw8oQtJtEX9fWn?usp=drive_link
  
## Akreditasi Program Studi Penyiaran (D3)
Kode Prodi: A24
Program Studi: Penyiaran
Jenjang: Diploma
No SK Akreditasi: 4414/SK/BAN-PT/Ak-PPJ/Dipl-III/VIII/2020
Peringkat Terbaru: B
Masa Berlaku: 02 Agustus 2025
Link Sertifikat: https://drive.google.com/drive/folders/15vGvjXGVGLOr1LeY7HPj-32W1-GekUAU?usp=drive_link
  
## Akreditasi Program Studi Teknik Informatika (Kampus Kota Kediri) (S1)
Kode Prodi: F11
Program Studi: Teknik Informatika (Kampus Kota Kediri)
Jenjang: Sarjana
No SK Akreditasi: 031/SK/LAM-INFOKOM/Ak.P/S/XII/2023
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 14 Desember 2028
Link Sertifikat: https://drive.google.com/drive/folders/1WcbftyWgIDqU7PCWeRkLwryHZWBuqJT0?usp=drive_link
  
## Akreditasi Program Studi Sistem Informasi (KAmpus Kota Kediri) (S1)
Kode Prodi: F12
Program Studi: Sistem Informasi (Kampus Kota Kediri)
Jenjang: Sarjana
No SK Akreditasi: 3017/SK/BAN-PT/Ak-PNB/S/V/2022
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 22 Juni 2026
Link Sertifikat: https://drive.google.com/drive/folders/1WBipHDoBqfNqKgl2GdqsEp1O6q3-zdmr?usp=drive_link
  
## Akreditasi Program Studi Desain Komunikasi Visual (Kampus Kota Kediri) (S1)
Kode Prodi: F14
Program Studi: Desain Komunikasi Visual (Kampus Kota Kediri)
Jenjang: Sarjana
No SK Akreditasi: 2680/SK/BAN-PT/Ak/S/VII/2023
Peringkat Terbaru: Baik
Masa Berlaku: 11 Juli 2028
Link Sertifikat: https://drive.google.com/drive/folders/1OjiEZ4idcRcAOkwul96WiWtJeVb-0Pht?usp=drive_link
  
## Akreditasi Program Studi Manajemen (S3)
Kode Prodi: P42
Program Studi: Manajemen
Jenjang: Doktor
No SK Akreditasi: 1064/DE/A.5/AR.10/III/2024
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 01 Maret 2029
Link Sertifikat: https://drive.google.com/drive/folders/1IpIGSTsux0i2xswod7IzZQG61EGN5D3w?usp=drive_link
  
## Akreditasi Program Studi Manajemen (S2)
Kode Prodi: P32
Program Studi: Manajemen
Jenjang: Magister
No SK Akreditasi: 3654/SK/BAN-PT/Ak.KP/M/IX/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 23-Sep-25
Link Sertifikat: https://drive.google.com/drive/folders/16Ka1h1FkV_7OJJOO-2M2dki6dLjK_Ets?usp=drive_link
  
## Akreditasi Program Studi Akuntansi (S2)
Kode Prodi: P33
Program Studi: Akuntansi
Jenjang: Magister
No SK Akreditasi: 247/DE/A.5/AR.11/II/2024
Peringkat Terbaru: Baik
Masa Berlaku: 7 Februari 2026
Link Sertifikat: https://drive.google.com/drive/folders/1-A8RPxcC1b0y9DhsWSUk1aNhU0geqQmV?usp=drive_link
  
## Akreditasi Program Studi Manajemen (S1)
Kode Prodi: B11
Program Studi: Manajemen
Jenjang: Sarjana
No SK Akreditasi: 385/DE/A.5/AR.10/IV/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 17-Apr-28
Link Sertifikat: https://drive.google.com/drive/folders/15rxb8Knxs8v9s3-8F7MuxQoU48hdkTMg?usp=drive_link
  
## Akreditasi Program Studi Akuntansi (S1)
Kode Prodi: B12
Program Studi: Akuntansi
Jenjang: Sarjana
No SK Akreditasi: 1907/SK/BAN-PT/Ak.KP/S/V/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 28 Desember 2026
Link Sertifikat: https://drive.google.com/drive/folders/15pZXOzUOBBncHSpGHhTLSWM0Nlwk5F8_?usp=drive_link
  
## Akreditasi Program Studi Manajemen (Kampus Kota Kediri) (S1)
Kode Prodi: F13
Program Studi: Manajemen (Kampus Kota Kediri)
Jenjang: Sarjana
No SK Akreditasi: 643/DE/A.5/AR.10/VIII/2023
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 23 Agustus 2028
Link Sertifikat: https://drive.google.com/drive/folders/1VnO7pb5jpjbMR6x-FhgSD6BQxRDOWeoL?usp=drive_link
  
## Akreditasi Program Studi Bahasa Inggris (S1)
Kode Prodi: C11
Program Studi: Bahasa Inggris
Jenjang: Sarjana
No SK Akreditasi: 2489/SK/BAN-PT/Ak.KP/S/VI/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 20 Januari 2027
Link Sertifikat: https://drive.google.com/drive/folders/15o8zMuitonDUT6gAvkYK2aYK0AP0WIuh?usp=drive_link
  
## Akreditasi Program Studi Sastra Jepang (S1)
Kode Prodi: C12
Program Studi: Sastra Jepang
Jenjang: Sarjana
No SK Akreditasi: 2045/SK/BAN-PT/Ak.KP/S/V/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 24 Mei 2027
Link Sertifikat: https://drive.google.com/drive/folders/15o7lLtqeVp0quh9ufJF-uC7WLpGvYQdJ?usp=drive_link
  
## Akreditasi Program Studi Pengelolaan Perhotelan (D4)
Kode Prodi: C13
Program Studi: Pengelolaan Perhotelan
Jenjang: Sarjana Terapan
No SK Akreditasi: 6199/SK/BAN-PT/Ak.Ppj/STr/X/2024
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 25-Sep-29
Link Sertifikat: https://drive.google.com/drive/folders/15n4O8LQnajsuxWp1Nb8uI0-E_ZTlkFdb?usp=drive_link
  
## Akreditasi Program Studi Kesehatan Masyarakat (S2)
Kode Prodi: P34
Program Studi: Kesehatan Masyarakat
Jenjang: Magister
No SK Akreditasi: 0027/LAM-PTKes/Akr.PB/Mag/I/2024
Peringkat Terbaru: Baik
Masa Berlaku: 30 Januari 2026
Link Sertifikat: https://drive.google.com/drive/folders/1-GoaBTg8MgT0Qh7mn2cGP0KO71TqRfHl?usp=drive_link
  
## Akreditasi Program Studi Kesehatan Masyaralat (S1)
Kode Prodi: D11
Program Studi: Kesehatan Masyarakat
Jenjang: Sarjana
No SK Akreditasi: 0657/LAM-PTKes/Akr/Sar/XII/2020
Peringkat Terbaru: A
Masa Berlaku: 10 Desember 2025
Link Sertifikat: https://drive.google.com/drive/folders/15lHZIGYUTZWGvP67rfBXfETRyADoOsMF?usp=drive_link
  
## Akreditasi Program Studi Kesehatan Lingkungan (S1)
Kode Prodi: D12
Program Studi: Kesehatan Lingkungan
Jenjang: Sarjana
No SK Akreditasi: 0151/LAM-PTKes/Akr/Sar/II/2023
Peringkat Terbaru: Unggul
Masa Berlaku: 23 Februari 2028
Link Sertifikat: https://drive.google.com/drive/folders/16Wy1I1TwXs1Q2utURroroafcMM0gXowr?usp=drive_link
  
## Akreditasi Program Studi Rekam Medik dan Informasi Kesehatan (D3)
Kode Prodi: D22
Program Studi: Rekam Medik dan Informasi Kesehatan
Jenjang: Diploma
No SK Akreditasi: 0832/LAM-PTKes/Akr/Dip/IX/2022
Peringkat Terbaru: Unggul
Masa Berlaku: 29-Sep-27
Link Sertifikat: https://drive.google.com/drive/folders/16T4b3-wfHyG7oyfEC0IUFxqfmw6gDrUF?usp=drive_link
  
## Akreditasi Program Studi Teknik Elektro (S1)
Kode Prodi: E11
Program Studi: Teknik Elektro
Jenjang: Sarjana
No SK Akreditasi: 5508/SK/BAN-PT/Ak.KP/S/VIII/2022
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 20 Oktober 2025
Link Sertifikat: https://drive.google.com/drive/folders/16Q8v8T6r7Dl74Rek2KNyGXTQyQsMu8Ju?usp=drive_link
  
## Akreditasi Program Studi Teknik Industri (S1)
Kode Prodi: E12
Program Studi: Teknik Industri
Jenjang: Sarjana
No SK Akreditasi: 5192/SK/BAN-PT/Ak.KP/S/VIII/2022
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 3-Sep-26
Link Sertifikat: https://drive.google.com/drive/folders/16Q6lRaqDbteaetM9ZxqtNj5ywsOV35wq?usp=drive_link
  
## Akreditasi Program Studi Teknik Biomedis (S1)
Kode Prodi: E13
Program Studi: Teknik Biomedis
Jenjang: Sarjana
No SK Akreditasi: 0351/SK/LAM Teknik/AS/VIII/2024
Peringkat Terbaru: Baik Sekali
Masa Berlaku: 20 Agustus 2029
Link Sertifikat: https://drive.google.com/drive/folders/16N15CA80tayDm7eZgmkBEtMJ89oelMEQ?usp=drive_link
  
## Akreditasi Program Studi Kedokteran (S1)
Kode Prodi: K11
Program Studi: Kedokteran
Jenjang: Sarjana
No SK Akreditasi: 0034/LAM-PTKes/Akr.PB/Sar/I/2024
Peringkat Terbaru: Baik
Masa Berlaku: 30 Januari 2026
Link Sertifikat: https://drive.google.com/drive/folders/1uJ0mIeT9NTsi0GbPa2JRiYHDD_ogC8f-?usp=drive_link
  
## Akreditasi Program Studi Profesi Kedokteran
Kode Prodi: K12
Program Studi: Pendidikan Profesi Doketer
Jenjang: Profesi
No SK Akreditasi: 0035/LAM-PTKes/Akr.PB/Pro/I/2024
Peringkat Terbaru: Baik
Masa Berlaku: 30 Januari 2026
Link Sertifikat: https://drive.google.com/drive/folders/1-2mnmej_Ir9bfgeGf_0YyKcs2wn2wFt4?usp=drive_link
  
## Akreditasi Program Studi Akuntansi (D3)
Kode Prodi: –
Program Studi: Akuntansi
Jenjang: Diploma
No SK Akreditasi: 00602/Ak-VI/Dpl-III-010/SN5AKT/IX/2006
Peringkat Terbaru: A
Masa Berlaku: 1-Sep-11
Link Sertifikat: https://drive.google.com/drive/folders/15ouIU1kO8wMImsYFQmbxSEFNjEvKrK0V?usp=drive_link
  
## Akreditasi Program Studi Bahasa Inggris (D3)
Kode Prodi: –
Program Studi: Bahasa Inggris
Jenjang: Diploma
No SK Akreditasi: 017/BAN-PT/Ak-VI/Dpl-III/XII/2006
Peringkat Terbaru: B
Masa Berlaku: 30 Desember 2006
Link Sertifikat: https://drive.google.com/drive/folders/15mTkSKusyp9-Ybm1w6J8D8qjSC17LrYa?usp=drive_link
  
## Akreditasi Program Studi Komputerisasi Akuntansi (D3)
Kode Prodi: –
Program Studi: Komputerisasi Akuntansi
Jenjang: Diploma
No SK Akreditasi: 017/BAN-PT/Ak-VI/Dpl-III/XII/2006
Peringkat Terbaru: B
Masa Berlaku: 30 Desember 2011
Link Sertifikat: https://drive.google.com/drive/folders/15x37aU5n7h4PFPkpHEeXvQF4HpbTLGcS?usp=drive_link
  
## Akreditasi Program Studi Manajemen Informatika (D3)
Kode Prodi: –
Program Studi: Manajemen Informatika
Jenjang: Diploma
No SK Akreditasi: 087/SK/BAN-PT/Akred/Dpl-III/III/2015
Peringkat Terbaru: B
Masa Berlaku: 14 Maret 2020
Link Sertifikat: https://drive.google.com/drive/folders/169urx1uS6qUpAL85_NdWciJkrF6AIB2x?usp=drive_link
  
## Akreditasi Program Studi Manajemen Informasi (S1)
Kode Prodi: –
Program Studi: Manajemen Informatika
Jenjang: Sarjana
No SK Akreditasi: 03861/Ak-1-III-019/SN5MEI/VIII/2000
Peringkat Terbaru: B
Masa Berlaku: 10 Agustus 2005
Link Sertifikat: https://drive.google.com/drive/folders/16KFZ5Ap8mw2AgS70N0YfhN-h9oEXnueQ?usp=drive_link
  
