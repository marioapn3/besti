# FAQ Pimpinan UDINUS 

## Siapa rektor Universitas Dian Nuswantoro (UDINUS) saat ini?
Rektor UDINUS saat ini adalah Prof. Dr. Ir. Edi Noersasongko, M.Kom, yang juga merupakan pendiri universitas.

## Siapa yang menjabat sebagai Wakil Rektor 1 UDINUS?
Wakil Rektor 1 UDINUS yang menangani bidang akademik adalah Prof. Dr. Supriadi Rustad, M.Si.

## Apa bidang yang diurus oleh Wakil Rektor 2 UDINUS?
Wakil Rektor 2, Dr. Guruh Fajar Shidik, S.Kom., M.Cs., mengurus bidang umum dan keuangan.

## Siapa Wakil Rektor yang bertanggung jawab di bidang kemahasiswaan?
Dr. Kusni Ingsih, MM, adalah Wakil Rektor 3 yang bertanggung jawab di bidang kemahasiswaan.

## Siapa yang menjabat sebagai Wakil Rektor 4 UDINUS dan apa bidangnya?
Prof. Dr. Pulung Nurtantio Andono, S.T., M.Kom., adalah Wakil Rektor 4 yang mengurus bidang penelitian dan kerja sama.

## Siapa yang memimpin Biro Administrasi Akademik di UDINUS?
Achmad Wahid Kurniawan, S.Si., M.Kom., memimpin Biro Administrasi Akademik UDINUS.

## Siapa yang bertanggung jawab di Biro Keuangan UDINUS?
Biro Keuangan UDINUS dipimpin oleh Yunita, S.E., M.Si.

## Siapa Kepala Biro Kemahasiswaan di UDINUS?
Dr. Rindra Yusianto, S.Kom., M.T., adalah Kepala Biro Kemahasiswaan UDINUS.

## Siapa yang memimpin Biro Admisi dan Promosi di UDINUS?
Kepala Biro Admisi dan Promosi UDINUS adalah Andi Hallang Lewa, S.S., M.M.

## Siapa Kepala Biro Umum UDINUS?
Sarju, S.Kom., M.M., adalah Kepala Biro Umum UDINUS adalah Sarju, S.Kom., M.M.

## Apa fungsi dari Lembaga Penelitian dan Pengabdian Masyarakat di UDINUS?
Lembaga ini bertugas untuk mengelola penelitian dan pengabdian masyarakat, serta dipimpin oleh Dr. Eng. Yuliman Purwanto, M.Eng.

## Siapa yang memimpin Lembaga Center Of Excellence di UDINUS?
Lembaga Center Of Excellence UDINUS dipimpin oleh Prof. Dr. Drs. Jumanto, M.Pd.

## Apa tugas dari Lembaga Pengembangan dan Pembelajaran Kurikulum di UDINUS?
Lembaga ini bertugas mengembangkan kurikulum dan proses pembelajaran. Pimpinannya adalah Dr. Pujiono, S.Si., M.Kom.

## Siapa yang memimpin Lembaga Kerjasama UDINUS?
Lembaga Kerjasama UDINUS dipimpin oleh Dr. Ir. Dwi Eko Waluyo, M.M.

## Apa fungsi dari Lembaga Penjamin Mutu di UDINUS?
Lembaga Penjamin Mutu bertanggung jawab atas kualitas dan standar akademik, dipimpin oleh Dr. Nova Rijati, S.Si., M.Kom.

## Siapa Kepala UPT Data dan Informasi UDINUS?
UPT Data dan Informasi UDINUS dipimpin oleh Dr. Heribertus Himawan, M.Kom.

## Siapa yang bertanggung jawab atas UPT Poliklinik di UDINUS?
Dr. Anggoro Dhana Octavian bertanggung jawab atas UPT Poliklinik UDINUS.

## Apa tugas UPT Layanan Alumni dan Karir di UDINUS?
UPT ini bertugas mendukung alumni dalam pengembangan karir. Pimpinan UPT ini adalah Dr. Sendi Novianto, S.Kom., M.T.

## Siapa yang memimpin UPT Kewirausahaan di UDINUS?
Dr. Nila Tristiarini, S.E., M.Si., CSRA, memimpin UPT Kewirausahaan di UDINUS.

## Siapa kepala dari UPT Dinustek?
Moch. Siddiq, S.Si., M.Kom., adalah Kepala UPT Dinustek di UDINUS.

## Siapa yang memimpin UPT Perpustakaan UDINUS?
UPT Perpustakaan dipimpin oleh Aan Prabowo, S.Hum., MA.

## Apa fungsi UPT Lembaga Sertifikasi dan Profesi di UDINUS?
UPT ini bertugas untuk menyelenggarakan sertifikasi dan pengembangan profesi, dipimpin oleh Dr. Supriyono Asfawi, S.E., M.Kes.

## Siapa Kepala UPT Humas dan Protokoler di UDINUS?
UPT Humas dan Protokoler UDINUS dipimpin oleh Dwi Utaminingsih, S.Kom., M.M.

## Siapa yang bertanggung jawab di UPT Penerbitan UDINUS?
Kepala UPT Penerbitan UDINUS adalah Achmintarto, S.Kom., M.M.

## Bagaimana peran Wakil Rektor di UDINUS?
Wakil Rektor UDINUS berperan mendukung Rektor dengan tanggung jawab di bidang akademik, keuangan, kemahasiswaan, serta penelitian dan kerja sama.

## Apa tugas Biro Administrasi Akademik di UDINUS?
Biro ini bertanggung jawab atas pengelolaan administrasi akademik mahasiswa, seperti pendaftaran, nilai, dan jadwal.

## Apa yang diurus oleh Biro Keuangan UDINUS?
Biro Keuangan mengelola keuangan universitas, termasuk anggaran dan pembayaran.

## Apa tugas dari Biro Kemahasiswaan UDINUS?
Biro Kemahasiswaan bertugas mengelola kegiatan dan layanan yang mendukung mahasiswa di luar akademik.

## Apa peran dari UPT Data dan Informasi UDINUS?
UPT ini menyediakan layanan data dan informasi yang diperlukan oleh civitas akademika dan publik.

## Apa tujuan dari Lembaga Center Of Excellence di UDINUS?
Tujuan Lembaga Center Of Excellence adalah menjadi pusat unggulan yang mendukung kegiatan penelitian dan inovasi di UDINUS.