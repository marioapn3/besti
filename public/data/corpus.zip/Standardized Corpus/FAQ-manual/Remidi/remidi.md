## Kapan pendaftaran remidial?

Pendaftaran remidial berlangsung dari **29 Januari hingga 31 Januari 2024**.

## Kapan pembayaran remidial?

Pembayaran remidial bisa dilakukan mulai **29 Januari hingga 2 Februari 2024** melalui Virtual Account Bank Jateng sesuai nominal tagihan yang tertera.

## Kapan pelaksanaan remidial dimulai?

Pelaksanaan remidial dijadwalkan dari **1 Februari hingga 14 Februari 2024**.

## Kapan batas akhir input nilai remidial?

Batas akhir input nilai remidial adalah **15 Februari 2024**.

## Kapan hasil UAS Tahap II diumumkan?

Hasil UAS Tahap II akan diumumkan pada **16 Februari 2024**.

## Apa saja syarat mengikuti remidial?

Mahasiswa harus aktif dan memiliki KRS pada semester berjalan, absensi pada perkuliahan reguler minimal 75% (atau mendapat izin dosen pengampu), dan telah mengikuti UAS reguler.

## Apakah nilai remidial bisa melebihi B?

Tidak, nilai akhir maksimal yang bisa dicapai melalui remidial adalah **B**.

## Bagaimana cara melakukan input mata kuliah remidial?

Input mata kuliah remidial dilakukan melalui **SiAdin** masing-masing mahasiswa. Pastikan untuk membaca ketentuan input yang tertera pada form remidial.

## Apakah bisa menambah atau mengedit mata kuliah setelah divalidasi?

Tidak, setelah divalidasi, mahasiswa **tidak bisa mengedit atau menambah mata kuliah remidial**.

## Apakah remidial menjamin perubahan nilai?

Tidak, remidial tidak menjamin perubahan nilai (huruf).

## Bagaimana cara konfirmasi pembayaran remidial?

Untuk konfirmasi pembayaran atau informasi lebih lanjut mengenai remidial, mahasiswa dapat menghubungi WhatsApp Official UDINUS di 08112685577.

## Apakah ada tutorial aktivasi email dan SiAdin?

Ya, terdapat tutorial untuk aktivasi email dan SiAdin bagi mahasiswa baru atau untuk reset password SiAdin bagi mahasiswa lama.

## Apakah saya perlu menghubungi dosen setelah mendaftar remidial?

Ya, mahasiswa harus segera menghubungi dosen pengampu mata kuliah terkait dan menunjukkan bukti keikutsertaan remidial yang telah divalidasi oleh BIKU.

## Apa saja kontak dan alamat untuk informasi lebih lanjut?

## Dimana Alamat Universitas Dian Nuswantoro:

Alamat Universitas Dian Nuswantoro berada di Jalan Imam Bonjol No. 207 Semarang, Kode Pos: 50131

## Berapa nomor WhatsApp Official Udinus Dian Nuswantoro (UDINUS)?

Nomor WhatsApp Official Universitas Dian Nuswantoro yaitu 08112685577
